// header.h

#include <stdio.h>


int dummy_fucntion(){
	printf("I am dumb\n");

	return 0;
}
// Part 5  MCP v5.0

#include "header.h"
#include <stdio.h>


int main(int argc, char *argv[]) {
	printf("RUNNING PART 5\n");

	return 0;
}